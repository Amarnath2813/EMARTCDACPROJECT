// login.jsx
import React, { useState } from 'react';
import { Form, Button, Card, Alert } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Login.css'; // Import custom CSS file for additional styling

export default function LoginComponent() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [loginError, setLoginError] = useState('');

  const handleLogin = () => {
    const url = 'http://localhost:8080/customer/login';

    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    })
      .then(response => response.json())
      .then(data => {
        if (data) {
          alert('Login successful');
        } else {
          alert('Invalid email or password');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        setLoginError('An error occurred while logging in. Please try again later.');
      });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (password.length < 8) {
      setPasswordError('Password must be at least 8 characters long');
      return;
    }
    setPasswordError('');
    setLoginError('');
    handleLogin();
  };

  return (
    <div className="d-flex justify-content-center align-items-center min-vh-100">
      <div className="col-12 col-sm-10 col-md-8 col-lg-6 col-xl-5 col-xxl-4">
        <Card className="border border-light-subtle rounded-3 shadow-sm">
          <Card.Body className="p-3 p-md-4 p-xl-5">
            <div className="text-center mb-3">
              <a href="#!">
                <img src="./assets/img/bsb-logo.svg" alt="BootstrapBrain Logo" width="175" height="57" />
              </a>
            </div>
            <h2 className="fs-6 fw-normal text-center text-secondary mb-4">Sign in to your account</h2>
            <Form onSubmit={handleSubmit}>
              <div className="row gy-2 overflow-hidden">
                <div className="col-12">
                  <div className="form-floating mb-3">
                    <Form.Control
                      type="email"
                      placeholder="name@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                    <label>Email</label>
                  </div>
                </div>
                <div className="col-12">
                  <div className="form-floating mb-3">
                    <Form.Control
                      type="password"
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                    <label>Password</label>
                    {passwordError && <Alert variant="danger">{passwordError}</Alert>}
                  </div>
                </div>
                <div className="col-12">
                  <div className="d-flex gap-2 justify-content-between">
                    <div className="form-check">
                      <Form.Check type="checkbox" label="Keep me logged in" />
                    </div>
                    <a href="#!" className="link-primary text-decoration-none">Forgot password?</a>
                  </div>
                </div>
                <div className="col-12">
                  <div className="d-grid my-3">
                    <Button variant="primary" type="submit" className="btn-lg">Log in</Button>
                  </div>
                </div>
                <div className="col-12">
                  <p className="m-0 text-secondary text-center">Don't have an account? <a href="/register" className="link-primary text-decoration-none">Create New Account</a></p>
                </div>
              </div>
            </Form>
          </Card.Body>
        </Card>
      </div>
    </div>
  );
}
