import React, { useState, useEffect } from 'react';

const GetAllCustomers = () => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/customer');
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const result = await response.json();
        setCustomers(result);
      } catch (error) {
        setError(error);
      }
      setLoading(false);
    };

    fetchData();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return (
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Gender</th>
          <th>Reedeem Points</th>
          <th>Address Line 1</th>
          <th>Address Line 2</th>
          <th>Pincode</th>
        </tr>
      </thead>
      <tbody>
        {customers.map(customer => (
          <tr key={customer.id}>
            <td>{customer.id}</td>
            <td>{customer.name}</td>
            <td>{customer.email}</td>
            <td>{customer.gender}</td>
            <td>{customer.reedeemPoints}</td>
            <td>{customer.addressLine1}</td>
            <td>{customer.addressLine2}</td>
            <td>{customer.pincode}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default GetAllCustomers;
