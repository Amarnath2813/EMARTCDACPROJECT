import React, { useState, useEffect } from 'react';
import { Container, Card } from 'react-bootstrap';
import Subcategories from './Subcategories';
import { useParams } from 'react-router-dom';

const Electronics = () => {
  const { id } = useParams();

  const toproduct = () => {
    // Define the behavior when clicking on a product
    // For example, you can navigate to the product details page.
    console.log('Clicked on a product');
  };

  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const fetchTopLevelCategories = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/products');
        const data = await response.json();
        setCategories(data);
      } catch (error) {
        console.error('Error fetching top-level categories:', error);
      }
    };

    fetchTopLevelCategories();
  }, []); // Ensure to pass an empty dependency array to run the effect only once

  return (
    <>
      <Container className="album py-5 bg-light">
        <Container>
          <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            {[1, 2, 3].map((index) => (
              <div className="col" key={index}>
                <Card className="shadow-sm" onClick={toproduct}>
                  <Card.Img src={`./Images/Electronics${index}.jpg`} alt={`Image ${index}`} width="100%" height="200" />
                  <Card.ImgOverlay>
                    <Card.Link href="#">Product link</Card.Link>
                  </Card.ImgOverlay>
                </Card>
              </div>
            ))}
          </div>
        </Container>
      </Container>
      <Subcategories categoryId={parseInt(id)} /> {/* Ensure id is parsed as an integer */}
    </>
  );
};

export default Electronics;
