import React from 'react';
import { useState, useEffect } from "react";
function ListProduct() {
    const [products, setProducts] = useState([]);
    useEffect(() => {
        fetch(" http://localhost:8080/api/products")
            .then(res => res.json())
            .then((result) => { setProducts(result); }
            );
    }, []);
    return (
        <div>
            <table> 
                <tbody>
                    {products.map(pro =>(
                        <tr key={pro.productId}>    
                        <td>{pro.catMasterId}</td> 
                            <td>{pro.productShortDesc}</td>
                            <td>{pro.productLongDesc}</td>
                            <td>{pro.cardHoldersPrice}</td>
                            <td>{pro.points_2b_Redeem}</td>
                            <td>{pro.remarks}</td>
                            <td>{pro.mrp_Price}</td>
                        </tr>
                     ))
                    }
                </tbody> </table>
        </div>
    );
}
export default ListProduct;
