import React, { useState, useEffect } from 'react';
import { Container, Card } from 'react-bootstrap';

const Subcategories = ({ categoryId }) => {
  const [subcategories, setSubcategories] = useState([]);

  useEffect(() => {
    const fetchSubcategories = async () => {
      try {
        if (!isNaN(categoryId)) {
          const response = await fetch(`http://localhost:8080/categories/subcategories/${categoryId}`);
          const data = await response.json();
  
          // Check if data is an array before setting state
          if (Array.isArray(data)) {
            setSubcategories(data);
            console.log("data recievde");
          } else {
            console.error('Received data is not an array:', data);
          }
        }
      } catch (error) {
        console.error('Error fetching subcategories:', error);
      }
    };
  
    fetchSubcategories();
  }, [categoryId]);

  return (
    <div>
   <h1>Category Received</h1>
    </div>
  );
};

export default Subcategories;
