import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import './Navbar.css';

const NavigationMenu = () => {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const fetchTopLevelCategories = async () => {
      try {
        const response = await fetch('http://localhost:8080/categories/allTopLevel');
        const data = await response.json();
        setCategories(data);
      } catch (error) {
        console.error('Error fetching top-level categories:', error);
      }
    };

    fetchTopLevelCategories();
  }, []);

  return (
    <Navbar expand="lg" variant="dark" className="navbar-custom">
      <Navbar.Brand>
        <Link to="/home">
          <svg width="30" height="22" viewBox="0 0 40 32" fill="none" xmlns="http://www.w3.org/2000/svg">
            {}
          </svg>
          My Emart
        </Link>
      </Navbar.Brand>

      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="mr-auto">
          {categories.map((category) => (
            <Nav.Link key={category.catId} as={Link} to={`/category/${category.catId}`}>
              {category.catName}
            </Nav.Link>
          ))}
          <Nav.Link as={Link} to="/login">
            Login
          </Nav.Link>
          <Nav.Link as={Link} to="/register">
            Register
          </Nav.Link>
          <Nav.Link as={Link} to="/AboutPage">
            About Us
          </Nav.Link>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
};

export default NavigationMenu;
