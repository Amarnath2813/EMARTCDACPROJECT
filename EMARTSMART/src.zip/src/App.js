import React from 'react';
import Navbar from './Navbar'; // Add this line
import { Outlet } from 'react-router-dom'; // Add this line
import HomePage from './Home';


function App() {
  return (
    <>
      
       <Navbar />
       
      <Outlet />
    </>
  );
}

export default App;
