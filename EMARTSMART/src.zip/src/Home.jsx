// Home.jsx

import React from 'react';
import { Container, Carousel, Card, Badge } from 'react-bootstrap';
import ProductRating from './ProductRating'; // Import the ProductRating component
import './Home.css'; // Import custom CSS for HomePage

const HomePage = () => {
  const carouselImages = [1, 2, 3, 4]; // Add the indices of your carousel images here
  return (
    <>
       {/* Carousel */}
       <Carousel id="home-carousel" className="mt-3">
        {carouselImages.map((index) => (
          <Carousel.Item key={index}>
            <div className="carousel-content">
              <img className="d-block w-100 carousel-img" src={`web${index}.jpg`} alt={`Slide ${index}`} />
              <Carousel.Caption className="carousel-caption">
                <h2>Welcome to Emart</h2>
                <h3>Special Offer: 20% Off</h3>
                <p>Price: <span className="offer-price">MRP 500</span> <span className="original-price">MRP 1000</span></p>
              </Carousel.Caption>
            </div>
          </Carousel.Item>
        ))}
      </Carousel>

      {/* Offers Section */}
      <Container className="py-5">
        <h2 className="text-center mb-4">Special Offers</h2>
        <div className="row row-cols-1 row-cols-md-3 g-4">
          <div className="col">
            <Card className="shadow-sm h-100">
              <Card.Img variant="top" src="samsung.jpg" />
              <Card.Body>
                <Badge bg="warning">Limited Time Offer</Badge>
                <h5 className="card-title mt-2">Get 20% Off</h5>
                <p className="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </Card.Body>
            </Card>
          </div>
          <div className="col">
            <Card className="shadow-sm h-100">
              <Card.Img variant="top" src="nikon.jpg" />
              <Card.Body>
                <Badge bg="danger">Flash Sale</Badge>
                <h5 className="card-title mt-2">Buy 1 Get 1 Free</h5>
                <p className="card-text">Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
              </Card.Body>
            </Card>
          </div>
          <div className="col">
            <Card className="shadow-sm h-100">
              <Card.Img variant="top" src="sony.jpg" />
              <Card.Body>
                <Badge bg="success">Hot Deal</Badge>
                <h5 className="card-title mt-2">Flat 50% Off</h5>
                <p className="card-text">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
              </Card.Body>
            </Card>
          </div>
        </div>
      </Container>

      {/* Product Grid */}
      <Container className="py-5">
        <h2 className="text-center mb-4">Best Sellers</h2>
        <div className="row row-cols-1 row-cols-md-3 g-3">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((index) => (
            <div className="col" key={index}>
              <Card className="h-100">
                <Card.Img src={`web${index}.jpg`} alt={`Product ${index}`} className="card-img-top" />
                <Card.Body>
                  <h5 className="card-title">OnePlus Nord CE 3 Lite 5G (Chromatic Gray, 8GB RAM, 128GB Storage)</h5>
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <ProductRating readOnly />
                      <span className="text-muted"></span>
                      <br />
                      <Badge bg="success">Best Seller</Badge>
                      <p className="mt-3">₹17,999 <span className="original-price">MRP: ₹19,999</span> (10% off)</p>
                      <p>Flat INR 100 Off on ICICI Credit Cards</p>
                    </div>
                    <div className="text-center">
                      <button className="btn btn-primary">Add to Cart</button>
                    </div>
                  </div>
                </Card.Body>
                <Card.Footer>
                  <small className="text-muted">Get it by Tomorrow, 16 February - FREE Delivery by Amazon</small>
                </Card.Footer>
              </Card>
            </div>
          ))}
        </div>
      </Container>
    </>
  );
}

export default HomePage;
