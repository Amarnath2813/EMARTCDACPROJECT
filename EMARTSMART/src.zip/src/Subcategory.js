import React, { useState, useEffect } from 'react';

const Subcategory = ({ categoryId }) => {
  const [subcategories, setSubcategories] = useState([]);

  useEffect(() => {
    // Fetch subcategories based on the selected category
    const fetchSubcategories = async () => {
      try {
        const response = await fetch(`http://localhost:8080/categories/${categoryId}/subcategories`);
        const data = await response.json();
        setSubcategories(data); // Update state with fetched subcategories
      } catch (error) {
        console.error('Error fetching subcategories:', error);
      }
    };

    fetchSubcategories();
  }, [categoryId]);

  return (
    <div>
      <h2>Subcategories</h2>
      <ul>
        {subcategories.map((subcategory) => (
          <li key={subcategory.id}>{subcategory.name}</li>
        ))}
      </ul>
    </div>
  );
};

export default Subcategory;
