import React, { useState } from 'react';
import './Registrationform.css';

const RegisterComponent = () => {
  const initialCustomerState = {
    name: '',
    email: '',
    phoneNo: '',
    gender: '',
    addressLine1: '',
    addressLine2: '',
    pincode: '',
    password: '',
    confirmPassword: '',
    reedeemPoints: 1000,
  };

  const [customer, setCustomer] = useState(initialCustomerState);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCustomer({ ...customer, [name]: value });
  };

  const handleClear = () => {
    setCustomer(initialCustomerState);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (customer.password !== customer.confirmPassword) {
      alert('Password and Confirm Password do not match.');
      return;
    }

    try {
      const response = await fetch('http://localhost:8080/customer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(customer),
      });

      if (!response.ok) {
        const errorMessage = await response.text();
        throw new Error(`Error: ${errorMessage}`);
      }

      alert('Registration successful!');
    } catch (error) {
      console.error('Error:', error);
      alert('Registration failed!');
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center">Register</h2>
      <form onSubmit={handleSubmit} className="mt-3">
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            value={customer.name}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={customer.email}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="phoneNo" className="form-label">Phone No:</label>
          <input
            type="text"
            id="phoneNo"
            name="phoneNo"
            value={customer.phoneNo}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="gender" className="form-label">Gender:</label>
          <select
            id="gender"
            name="gender"
            value={customer.gender}
            onChange={handleChange}
            className="form-control"
            required
          >
            <option value=""></option>
            <option value="M">Male</option>
            <option value="F">Female</option>
          </select>
        </div>
        <div className="mb-3">
          <label htmlFor="addressLine1" className="form-label">Address Line 1:</label>
          <input
            type="text"
            id="addressLine1"
            name="addressLine1"
            value={customer.addressLine1}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="addressLine2" className="form-label">Address Line 2:</label>
          <input
            type="text"
            id="addressLine2"
            name="addressLine2"
            value={customer.addressLine2}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="pincode" className="form-label">Pincode:</label>
          <input
            type="text"
            id="pincode"
            name="pincode"
            value={customer.pincode}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="reedeemPoints" className="form-label">Redeem Points:</label>
          <input
            type="text"
            id="reedeemPoints"
            name="reedeemPoints"
            value={customer.reedeemPoints}
            onChange={handleChange}
            className="form-control"
            disabled // Make it unchangeable
          />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            value={customer.password}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="confirmPassword" className="form-label">Confirm Password:</label>
          <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            value={customer.confirmPassword}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        <button type="submit" className="btn btn-primary">Register</button>
        <button type="button" className="btn btn-primary" style={{ backgroundColor: 'black', color: 'white', marginLeft: '10px' }} onClick={handleClear}>
          Clear All
        </button>



        <div className="col-12">
          <p className="m-0 text-secondary text-center"><a href="/home" className="link-primary text-decoration-none">Go to Home</a></p>
        </div>
      </form>
    </div>
  );
};

export default RegisterComponent;