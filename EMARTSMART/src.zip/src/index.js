import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import App from './App';
import RegistrationForm from './Registrationform'; // Check the correct path
import Login from './Component/Login'; // Check the correct path
import reportWebVitals from './reportWebVitals';
import NotFoundPage from './Error';
import AboutPage from './Aboustus';
import HomePage from './Home';
import Subcategories from './Component/Subcategories';

ReactDOM.createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<App />}>
        <Route path="/Home" element={< HomePage/>} />
        <Route path="/register" element={<RegistrationForm />} />
        <Route path="/login" element={<Login />} />
        <Route path="/AboutPage" element={<AboutPage />} />
        <Route path="/category/:categoryId" component={Subcategories} />

        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  </BrowserRouter>
);

reportWebVitals();
