// ProductRating.jsx

import React, { useState } from 'react';
import { Rating } from 'react-simple-star-rating';

export default function ProductRating() {
  const [rating, setRating] = useState(0);

  const handleRating = (newRating) => {
    setRating(newRating);
  }

  return (
    <Rating
      onClick={handleRating}
      ratingValue={rating}
      size={24} // Set the size of the star icons
    />
  );
}
